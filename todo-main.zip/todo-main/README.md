# TODO - Webprogramming 01

# deployed from my REPO : RockThePeople.github.io
[https://rockthepeople.github.io/]

## Available Scripts

In the project directory, you can run:
### `npm install`
### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.